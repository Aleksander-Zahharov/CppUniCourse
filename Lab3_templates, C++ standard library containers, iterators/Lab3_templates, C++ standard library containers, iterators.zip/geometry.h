#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "point.h"
#include "line.h"
#include "sphere.h"
#include "polygon.h"
#include "sum_vector.h"

// Include own headers
// NB! Add your own headers here!

#endif // GEOMETRY_H
