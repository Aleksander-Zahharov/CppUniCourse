// This is used to make sure that the same header is not included twice
#ifndef NELJAS_H
#define NELJAS_H

#include "Functions.h"
#include "Point2.h"
#include "DynamicLine.h"
#include "MyArray.h"


#endif // NELJAS
